class AlreadyStarted(Exception):
    pass